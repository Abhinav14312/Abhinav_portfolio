import pygame
import random

pygame.init()

# Screen dimensions and block size
WIDTH, HEIGHT = 300, 600
BLOCK_SIZE = 30
ROWS, COLS = HEIGHT // BLOCK_SIZE, WIDTH // BLOCK_SIZE

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (50, 50, 50)
COLORS = [
    (255, 0, 0),  # Red
    (0, 255, 0),  # Green
    (0, 0, 255),  # Blue
    (255, 255, 0),  # Yellow
    (255, 165, 0),  # Orange
    (128, 0, 128),  # Purple
]

# Tetromino shapes
SHAPES = [
    [[1, 1, 1, 1]],  # I-shape
    [[1, 1], [1, 1]],  # O-shape
    [[0, 1, 0], [1, 1, 1]],  # T-shape
    [[1, 1, 0], [0, 1, 1]],  # Z-shape
    [[0, 1, 1], [1, 1, 0]],  # S-shape
    [[1, 0, 0], [1, 1, 1]],  # L-shape
    [[0, 0, 1], [1, 1, 1]],  # J-shape
]

# Initialize screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Tetris")
clock = pygame.time.Clock()

# Grid initialization
grid = [[0] * COLS for _ in range(ROWS)]

# Tetromino class
class Tetromino:
    def __init__(self, shape, color):
        self.shape = shape
        self.color = color
        self.x = COLS // 2 - len(shape[0]) // 2
        self.y = 0

    def move_down(self):
        self.y += 1

    def move_left(self):
        self.x -= 1

    def move_right(self):
        self.x += 1

    def rotate(self):
        self.shape = [list(row) for row in zip(*self.shape[::-1])]

# Draw grid and blocks
def draw_grid():
    for x in range(0, WIDTH, BLOCK_SIZE):
        for y in range(0, HEIGHT, BLOCK_SIZE):
            rect = pygame.Rect(x, y, BLOCK_SIZE, BLOCK_SIZE)
            pygame.draw.rect(screen, GRAY, rect, 1)

def draw_blocks(grid):
    for y in range(ROWS):
        for x in range(COLS):
            if grid[y][x] != 0:
                color = COLORS[grid[y][x] - 1]
                pygame.draw.rect(screen, color, (x * BLOCK_SIZE, y * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE))

def draw_piece(piece):
    for y, row in enumerate(piece.shape):
        for x, cell in enumerate(row):
            if cell:
                pygame.draw.rect(
                    screen,
                    piece.color,
                    ((piece.x + x) * BLOCK_SIZE, (piece.y + y) * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE),
                )

# Collision detection
def check_collision(grid, piece):
    for y, row in enumerate(piece.shape):
        for x, cell in enumerate(row):
            if cell:
                new_x = piece.x + x
                new_y = piece.y + y
                if new_x < 0 or new_x >= COLS or new_y >= ROWS or grid[new_y][new_x]:
                    return True
    return False

# Lock piece in place
def lock_piece(grid, piece):
    for y, row in enumerate(piece.shape):
        for x, cell in enumerate(row):
            if cell:
                grid[piece.y + y][piece.x + x] = COLORS.index(piece.color) + 1

# Clear full rows
def clear_rows(grid):
    new_grid = [row for row in grid if 0 in row]
    cleared = ROWS - len(new_grid)
    new_grid = [[0] * COLS for _ in range(cleared)] + new_grid
    return new_grid, cleared

# Main game loop
running = True
current_piece = Tetromino(random.choice(SHAPES), random.choice(COLORS))
next_piece = Tetromino(random.choice(SHAPES), random.choice(COLORS))
score = 0

gravity_timer = pygame.USEREVENT + 1
pygame.time.set_timer(gravity_timer, 500)

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == gravity_timer:
            current_piece.move_down()
            if check_collision(grid, current_piece):
                current_piece.y -= 1
                lock_piece(grid, current_piece)
                grid, cleared_rows = clear_rows(grid)
                score += cleared_rows * 10
                current_piece = next_piece
                next_piece = Tetromino(random.choice(SHAPES), random.choice(COLORS))
                if check_collision(grid, current_piece):
                    running = False  # Game over

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                current_piece.move_left()
                if check_collision(grid, current_piece):
                    current_piece.move_right()
            elif event.key == pygame.K_RIGHT:
                current_piece.move_right()
                if check_collision(grid, current_piece):
                    current_piece.move_left()
            elif event.key == pygame.K_DOWN:
                current_piece.move_down()
                if check_collision(grid, current_piece):
                    current_piece.y -= 1
            elif event.key == pygame.K_UP:
                current_piece.rotate()
                if check_collision(grid, current_piece):
                    current_piece.rotate()
                    current_piece.rotate()
                    current_piece.rotate()

    screen.fill(BLACK)
    draw_grid()
    draw_blocks(grid)
    draw_piece(current_piece)
    pygame.display.flip()
    clock.tick(30)

pygame.quit()
